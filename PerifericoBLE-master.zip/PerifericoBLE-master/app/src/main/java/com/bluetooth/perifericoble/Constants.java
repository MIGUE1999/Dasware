package com.bluetooth.perifericoble;

public class Constants {
    public static final String TAG="BLEPeripheral";
}
